import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class facebook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/login/");
		driver.findElement(By.id("email")).sendKeys("abc");
		
		driver.findElement(By.id("pass")).sendKeys("12345");
		driver.findElement(By.name("login")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		
		WebElement s = driver.findElement(By.linkText("Find your account and log in."));
		String k = s.getText();
		
		if(k.equals("Find your account and log in."))
			System.out.println("Test pass");
		else
			System.out.println("Test Fail");
		
		driver.manage().window().maximize();
		driver.close();
		
		
		
		

	}
}
